﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SMS.Services.SMSServices.DAL.Helper
{
  public  class ConnectionHelper
    {
        private readonly IConfiguration _configuration;

        public ConnectionHelper(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public string GetConnectionString()
        {
            string retValue = string.Empty;
            retValue = _configuration.GetConnectionString("postGreSqlConection");

            return retValue;
        }
    }
}
