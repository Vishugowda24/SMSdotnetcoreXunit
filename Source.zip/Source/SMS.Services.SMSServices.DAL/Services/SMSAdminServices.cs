﻿using Microsoft.EntityFrameworkCore;
using Npgsql;
using SMS.Services.SMSServices.DAL.Interfaces;
using SMS.Services.SMSServices.DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dapper;
using System.Data;
using SMS.Services.SMSServices.DAL.Helper;
using Microsoft.Extensions.Configuration;

namespace SMS.Services.SMSServices.DAL.Services
{
	public class SMSAdminServices : ISMSAdminServices
	{
		private SMSContext _testContext;
		private ConnectionHelper _connectionHelper;
		public SMSAdminServices(SMSContext smsContext,IConfiguration configuration)
		{
			_testContext = smsContext;
			_connectionHelper = new ConnectionHelper(configuration);
		}

        public List<Serviceregistration> GetServices()
        {
            var serviceUrl = from service in _testContext.Serviceregistration
                             select new Serviceregistration
                             {
                                 Id = service.Id,
                                 Url = service.Url
                             };

            return serviceUrl.ToList();
        }

        //public Users GetUsers1()
        //{
        //	var test = from test1 in _testContext.Vishtest

        //	select new Users
        //	{
        //		Id = test1.Id,
        //		Name = test1.Name
        //	};
        //	//{
        //	//	Id = 1,
        //	//	Name = "vish"
        //	//};

        //	return test.FirstOrDefault();
        //}

        //public Users GetUsers()
        //{
        //	List<Users> users = new List<Users>();
        //	using ( var con = new NpgsqlConnection(_connectionHelper.GetConnectionString()))
        //          {
        //	var gridReader =con.Query<Users>("Select * from vishtest", commandType: CommandType.Text);
        //		users = gridReader.ToList();
        //	}

        //	return users.FirstOrDefault();
        //}

        public List<Serviceregistration> GetServiceUrl()
        {

			var serviceUrl = from service in _testContext.Serviceregistration
                       select new Serviceregistration
                       {
                           Id = service.Id,
                           Url = service.Url
                       };

			return serviceUrl.ToList();

		}

        public Users GetUsers()
        {
            throw new NotImplementedException();
        }
    }
}
