﻿using SMS.Services.SMSServices.DAL.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace SMS.Services.SMSServices.DAL.Interfaces
{
	public interface ISMSAdminServices
	{
		Users GetUsers();
		List<Serviceregistration> GetServices();

	}
}
