﻿using System;
using System.Collections.Generic;

namespace SMS.Services.SMSServices.DAL.Models
{
    public partial class Serviceregistration
    {
        public int Id { get; set; }
        public string Url { get; set; }
    }
}
