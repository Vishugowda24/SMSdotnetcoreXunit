﻿using System;
using System.Collections.Generic;

namespace SMS.Services.SMSServices
{
    public partial class Vishtest
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
