using Microsoft.AspNetCore.Mvc;
using Moq;
using SMS.Services.SMSServices.Business.Interfaces;
using SMS.Services.SMSServices.Contract;
using SMS.Services.SMSServices.Controllers;
using SMS.Services.SMSServices.Core;
using System;
using System.Collections.Generic;
using Xunit;

namespace SMS.UnitTest
{
    public class UnitTest1 : ControllerBase
    {
        public Mock<ISMSAdminServices> mockSMSService = new Mock<ISMSAdminServices>();
        public Mock<ILoggerManager> logger = new Mock<ILoggerManager>();

        public Mock<IDataLookupServices> mockDatalookupService = new Mock<IDataLookupServices>();



        [Fact]
        public async void GetEmployeebyId()
        {
            List<ServiceRegistration> service = new List<ServiceRegistration>();
            service.Add(new ServiceRegistration()); // You can build your mack response
            mockSMSService.Setup(p => p.GetServices()).Returns(service);
            SMSAdminController emp = new SMSAdminController(mockSMSService.Object, logger.Object,mockDatalookupService.Object);
            var result =  emp.GetServices();
            Assert.Equal(Ok(service), result);
        }
    }
}
