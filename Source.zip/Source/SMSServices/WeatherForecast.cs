using System;

namespace SMSServices
{
    public class WeatherForecast
    {
        public DateTime Date { get; set; }

        public int TemperatureC { get; set; }

        public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);

        public string Summary { get; set; }

        public override string ToString()
        {
            return "ddddddddddddd";
        }
    }


    public class WeatherForecast1
    {
        public DateTime Date { get; set; }

        public int TemperatureC { get; set; }

        public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);

        public string Summary { get; set; }

        public static bool operator *(WeatherForecast1 Weather1, WeatherForecast1 Weather2)
        {
            WeatherForecast1 WeatherForecast3 = new WeatherForecast1();
            WeatherForecast3.Summary = Weather1.Summary + "2222" + Weather2.Summary;
            return true;
        }


        public override string ToString()
        {
            return "ddddddddddddd1";
        }
    }
}
