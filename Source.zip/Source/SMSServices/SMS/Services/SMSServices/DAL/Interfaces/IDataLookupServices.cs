﻿namespace SMS.Services.SMSServices.DAL.Interfaces
{
    internal interface IDataLookupServices
    {
    }
}