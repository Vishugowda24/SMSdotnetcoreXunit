﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using SMS.Services.SMSServices.Contract;

namespace SMS.Services.SMSServices.Filters
{
    public class AppSettingsValidationStartupFilter : IStartupFilter
    {
        readonly IEnumerable<IValidatable> _validateObject;

        public AppSettingsValidationStartupFilter(IEnumerable<IValidatable> validateObjects)
        {
            _validateObject = validateObjects;
        }
        public Action<IApplicationBuilder> Configure(Action<IApplicationBuilder> next)
        {
            foreach (var validateObj in _validateObject)
            {
                validateObj.Validate();
            }

            return next;
        }
    }
}
