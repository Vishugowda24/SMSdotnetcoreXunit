using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using NpgsqlTypes;
using Npgsql;
using Npgsql.EntityFrameworkCore.PostgreSQL;
using SMS.Services.SMSServices;
using SMS.Services.SMSServices.Filters;
using SMS.Services.SMSServices.Contract;
using Microsoft.Extensions.Options;
using SMS.Services.SMSServices.ServiceExtensions;
using SMS.Services.SMSServices.Core;
using NLog;
using SMS.Services.SMSServices.GlobalExceptionHandler;
using AutoMapper;
using SMS.Services.SMSServices.DAL;
using System.Collections;

namespace SMSServices
{
    public class Startup
    {
        public Startup(IConfiguration configuration, IWebHostEnvironment env)
        {
            LogManager.LoadConfiguration(string.Concat(System.IO.Directory.GetCurrentDirectory(), "\\nlog.config"));
            Configuration = configuration;
            Environment = env;

        }

        public IConfiguration Configuration { get; }

        public IWebHostEnvironment Environment { get; }


        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddTransient<IStartupFilter, AppSettingsValidationStartupFilter>();
            services.Configure<AppSettings>(Configuration.GetSection("AppSettings"));
            services.AddSingleton(resolver => resolver.GetRequiredService<IOptions<AppSettings>>().Value);
            services.AddSingleton<IValidatable>(resolver => resolver.GetRequiredService<IOptions<AppSettings>>().Value);
            services.AddAutoMapper(typeof(Startup));
            var appSettings = Configuration.GetSection("AppSettings").Get<AppSettings>();
            services.ConfigureCors(appSettings);

            var c = 0x3333333;

            //Configure jwt
            services.AddControllers();

            if (Environment.IsDevelopment())
            {
                services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_3_0);
            }
            else
            {
                services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_3_0);
            }

            services.AddSingleton<ILoggerManager, LoggerManager>();
            services.AddScoped<SMS.Services.SMSServices.Business.Interfaces.ISMSAdminServices, SMS.Services.SMSServices.Business.Services.SMSAdminServices>();
            services.AddScoped<SMS.Services.SMSServices.Business.Interfaces.IDataLookupServices, SMS.Services.SMSServices.Business.Services.DataLookupServices>();

            services.AddScoped<SMS.Services.SMSServices.DAL.Interfaces.ISMSAdminServices, SMS.Services.SMSServices.DAL.Services.SMSAdminServices>();
            services.AddScoped<SMS.Services.SMSServices.Business.Interfaces.IDataLookupServices, SMS.Services.SMSServices.Business.Services.DataLookupServices>();

            services.AddEntityFrameworkNpgsql().AddDbContext<SMSContext>(opt =>
      opt.UseNpgsql(Configuration.GetConnectionString("postGreSqlConection")));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerManager logger)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
                app.UseDeveloperExceptionPage();

            }


            app.UseCors("SMSCorsPolicy");
            app.ConfigureExceptionHandler(logger);
            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
