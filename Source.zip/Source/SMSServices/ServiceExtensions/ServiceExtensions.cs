﻿using Microsoft.Extensions.DependencyInjection;
using SMS.Services.SMSServices.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SMS.Services.SMSServices.ServiceExtensions
{
    public static class ServiceExtensions
    {
        public static void ConfigureCors(this IServiceCollection services,AppSettings appSettings)
        {
            var corsPolicyOriginData = appSettings.CorsPolicyOriginUrl?.Split(',', StringSplitOptions.RemoveEmptyEntries);
            services.AddCors(option =>
            {
                option.AddPolicy("SMSCorsPolicy",
                builder =>
                {
                    builder.AllowAnyOrigin().
                    //WithOrigins(corsPolicyOriginData).
                    AllowAnyHeader().AllowAnyMethod();
                });
            });
        }

        //Add configure jwt
        //add configure api
    }
}
