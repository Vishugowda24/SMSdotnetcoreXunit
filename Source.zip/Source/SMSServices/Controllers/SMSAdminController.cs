﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SMS.Services.SMSServices.Business.Interfaces;
using SMS.Services.SMSServices.Contract;
using SMS.Services.SMSServices.Core;

namespace SMS.Services.SMSServices.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SMSAdminController : ControllerBase
    {
		private readonly ISMSAdminServices _smsAdminServices;
		private readonly IDataLookupServices _dataLookupService;

		private readonly ILoggerManager _logger;

		public SMSAdminController(ISMSAdminServices smsAdminServices, ILoggerManager logger,IDataLookupServices dataLookupServices)
		{
			_smsAdminServices = smsAdminServices;
			_dataLookupService = dataLookupServices;
			_logger = logger;
		}

		[HttpGet]
		[ProducesResponseType(typeof(Users),200)]
		[Route("users")]
		public ActionResult GetUsers()
		{
			_logger.LogInfo("Getuser started..");
			//throw new Exception("Ddddd");
			var result = _smsAdminServices.GetUsers();

			return Ok(result);
		}

		[HttpGet]
		[ProducesResponseType(typeof(List<ServiceRegistration>), 200)]
		[Route("Services")]
		public ActionResult GetServices()
		{
			_logger.LogInfo("GetServices started..");
			//throw new Exception("Ddddd");
			var result = _smsAdminServices.GetServices();
			
			return Ok(result);
		}


        [HttpPost]
        [ProducesResponseType(typeof(List<ServiceData>), 200)]
        [Route("ServiceData")]
        public ActionResult GetServiceData(ServiceRequest request)
        {
            _logger.LogInfo("GetServiceData started..");
            //throw new Exception("Ddddd");
            var result = _dataLookupService.GetServiceData(request);
            return Ok(result);
        }
    }
}