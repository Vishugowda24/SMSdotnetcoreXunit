﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace SMSServices.Controllers
{
    class LinkedList<Tnode>
    {
        public LinkedList(Tnode t,LinkedListNode<Tnode> next = null)
        {
            this.Value = t;
            this.Next = next;
        }

        public LinkedListNode<Tnode> Next;
        public Tnode Value;
    }


    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {

        public  bool MiissingNumberInSequence1(int[] input, int value)
        {
            List<int> foundValue = new List<int>();
            foreach (var item in input)
            {
                if (foundValue.Contains(value - item))
                    return true;

                foundValue.Add(item);
            }


            return false;
        }
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IEnumerable<WeatherForecast> Get()
        {
            int[] missingNumberInSequence = new int[] { 1, 2, 3, 5, 6, 7 };
            bool output = MiissingNumberInSequence1(missingNumberInSequence, 44);
            Console.WriteLine(output);
            string[] arr = new string[6];

            string s = "dddddddd";
            char[] d = s.ToCharArray();
            var dd = new WeatherForecast1() == new WeatherForecast1();
            var rng = new Random();
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = rng.Next(-20, 55),
                Summary = Summaries[rng.Next(Summaries.Length)]
            })
            .ToArray();
        }
    }
}
