﻿using System;

namespace SMS.Services.SMSServices.Business
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
