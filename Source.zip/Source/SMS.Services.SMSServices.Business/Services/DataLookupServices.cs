﻿using SMS.Services.SMSServices.Business.Interfaces;
using SMS.Services.SMSServices.Contract;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;

namespace SMS.Services.SMSServices.Business.Services
{
    public class DataLookupServices : IDataLookupServices
    {
        public List<ServiceData> GetServiceData(ServiceRequest request)
        {
            using (var client = new HttpClient())
            {
                var result = client.GetAsync(request.Url);
                var data = result.Result;
            }
            return new List<ServiceData>()
            {
                new ServiceData()
                {
                    Id=1,RepoName ="BDServices"
                }

            };
        }


    }
    
}
