﻿using SMS.Services.SMSServices.Business.Interfaces;
using SMS.Services.SMSServices.Contract;
using System;
using System.Collections.Generic;
using System.Text;
using  sms= SMS.Services.SMSServices.DAL.Interfaces;
using hleper= SMS.Services.SMSServices.Business.TranslateHelper.TranslateHelper;
using AutoMapper;

namespace SMS.Services.SMSServices.Business.Services
{
	public class SMSAdminServices : Profile,ISMSAdminServices
	{
		private readonly IMapper _mapper;

		private readonly sms.ISMSAdminServices _smsAdminServices;

		public SMSAdminServices(sms.ISMSAdminServices smsAdminServices, IMapper mapper)
		{
			_smsAdminServices = smsAdminServices;
			_mapper = mapper;

		}

		public List<ServiceRegistration> GetServices()
        {
			
			//return null;
		return hleper.TranslateServices(_smsAdminServices.GetServices());
		}

        public Users GetUsers()
		{
			return hleper.TranslateUsers(_smsAdminServices.GetUsers());
		}
	}
}
