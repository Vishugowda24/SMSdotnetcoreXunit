﻿using SMS.Services.SMSServices.Contract;
using System;
using System.Collections.Generic;
using System.Text;
using SMS.Services.SMSServices.DAL;
using AutoMapper;

namespace SMS.Services.SMSServices.Business.TranslateHelper
{
	public static class TranslateHelper 
	{
		


		public static Users TranslateUsers(SMS.Services.SMSServices.DAL.Models.Users user)
		{
			return new Users()
			{
				Id = user.Id,
				Name = user.Name
			};

		}


		public static List<ServiceRegistration> TranslateServices(List<SMS.Services.SMSServices.DAL.Models.Serviceregistration> services)
		{
			List<ServiceRegistration> serviceReg = new List<ServiceRegistration>();
            foreach (var item in services)
            {
				serviceReg.Add(new ServiceRegistration() { Id = item.Id, Url = item.Url });
			}
			return serviceReg;

		}

	}
}
