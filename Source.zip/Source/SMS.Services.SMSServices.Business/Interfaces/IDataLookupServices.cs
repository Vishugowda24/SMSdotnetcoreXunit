﻿using SMS.Services.SMSServices.Contract;
using System;
using System.Collections.Generic;
using System.Text;

namespace SMS.Services.SMSServices.Business.Interfaces
{
  public  interface IDataLookupServices
    {
        List<ServiceData> GetServiceData(ServiceRequest request);

    }
}
