﻿using SMS.Services.SMSServices.Contract;
using System;
using System.Collections.Generic;
using System.Text;

namespace SMS.Services.SMSServices.Business.Interfaces
{
public	interface ISMSAdminServices
	{
		Users GetUsers();
		List<ServiceRegistration> GetServices();
	}
}
