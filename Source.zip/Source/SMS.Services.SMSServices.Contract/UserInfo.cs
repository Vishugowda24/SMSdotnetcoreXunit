﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMS.Services.SMSServices.Contract
{
  public  class UserInfo
    {
        public UserData userData { get; set; }
    }
}
