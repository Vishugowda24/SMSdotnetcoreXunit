﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMS.Services.SMSServices.Contract
{
  public  class ServiceRegistration
    {
        public int Id { get; set; }
        public string Url { get; set; }
    }
}

