﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMS.Services.SMSServices.Contract
{
   public class UserData
    {
        public int User_id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }

        public string UserName { get; set; }

        public string Token { get; set; }



    }
}
