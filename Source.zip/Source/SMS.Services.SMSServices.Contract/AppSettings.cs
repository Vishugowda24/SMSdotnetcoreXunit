﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace SMS.Services.SMSServices.Contract
{
    public class AppSettings : IValidatable
    {
        [Required]
        public string UserName { get; set; }

        [Required]
        public string CorsPolicyOriginUrl { get; set; }
        public void Validate()
        {
            Validator.ValidateObject(this, new ValidationContext(this), validateAllProperties: true);
        }
    }

    public interface IValidatable
    {
        void Validate();
    }
}
