﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace SMS.Services.SMSServices.Contract
{
   public class AitData
    {
        [Required]
        public string Mode { get; set; }

        public int Id {get; set; }

        [Required]
        public string AitNumber { get; set; }

        [Required]
        public string AitDescription { get; set; }

        [Required]
        public string AitContactName { get; set; }
        [Required]
        public string AitEmail { get; set; }

        

    }
}
